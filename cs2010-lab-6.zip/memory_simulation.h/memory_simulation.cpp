#include "memory_simulation.h"

// Generate a memory request
void generateMemoryRequest(int clock, std::vector<range> &freeList, std::vector<alloc> &allocatedList, 
                           int &totalRequests, int &satisfiedRequests, int &unsatisfiedRequests, 
                           int &smallestBlock, int &largestBlock, int &totalBlockSize, 
                           int &shortestLease, int &longestLease, int &totalLeaseTime, int &mergeCount) {
    int requestSize = rand() % (MAX_SIZE - MIN_SIZE) + MIN_SIZE;
    int leaseDuration = rand() % (MAX_LEASE - MIN_LEASE) + MIN_LEASE;

    totalRequests++;
    smallestBlock = std::min(smallestBlock, requestSize);
    largestBlock = std::max(largestBlock, requestSize);
    totalBlockSize += requestSize;

    shortestLease = std::min(shortestLease, leaseDuration);
    longestLease = std::max(longestLease, leaseDuration);
    totalLeaseTime += leaseDuration;

    auto it = std::find_if(freeList.begin(), freeList.end(), [&](const range &r) {
        return r.second >= requestSize;
    });

    if (it != freeList.end()) {
        range allocatedRange = {it->first, requestSize};
        allocatedList.emplace_back(allocatedRange, clock + leaseDuration);
        it->first += requestSize;
        it->second -= requestSize;
        if (it->second == 0) freeList.erase(it);
        satisfiedRequests++;
    } else {
        mergeFreeList(freeList);
        mergeCount++;
        it = std::find_if(freeList.begin(), freeList.end(), [&](const range &r) {
            return r.second >= requestSize;
        });

        if (it != freeList.end()) {
            range allocatedRange = {it->first, requestSize};
            allocatedList.emplace_back(allocatedRange, clock + leaseDuration);
            it->first += requestSize;
            it->second -= requestSize;
            if (it->second == 0) freeList.erase(it);
            satisfiedRequests++;
        } else {
            unsatisfiedRequests++;
        }
    }

    std::sort(allocatedList.begin(), allocatedList.end(), [](const alloc &a, const alloc &b) {
        return a.second < b.second;
    });
}

// Check if any leases have expired
void checkLeaseExpiry(int clock, std::vector<range> &freeList, std::vector<alloc> &allocatedList) {
    while (!allocatedList.empty() && allocatedList.front().second <= clock) {
        range returnedRange = allocatedList.front().first;
        freeList.push_back(returnedRange);
        allocatedList.erase(allocatedList.begin());
    }

    std::sort(freeList.begin(), freeList.end(), [](const range &a, const range &b) {
        return a.first < b.first;
    });
}

// Merge adjacent free memory blocks
void mergeFreeList(std::vector<range> &freeList) {
    if (freeList.empty()) return;

    std::sort(freeList.begin(), freeList.end(), [](const range &a, const range &b) {
        return a.first < b.first;
    });

    std::vector<range> mergedList;
    range current = freeList[0];

    for (size_t i = 1; i < freeList.size(); i++) {
        if (current.first + current.second == freeList[i].first) {
            current.second += freeList[i].second;
        } else {
            mergedList.push_back(current);
            current = freeList[i];
        }
    }
    mergedList.push_back(current);
    freeList = mergedList;
}

// Print statistics after simulation
void printStatistics(int totalRequests, int satisfiedRequests, int unsatisfiedRequests, 
                     int smallestBlock, int largestBlock, double averageBlockSize, 
                     int shortestLease, int longestLease, double averageLeaseTime, 
                     int mergeCount, const std::vector<range> &freeList, const std::vector<alloc> &allocatedList) {
    std::cout << "Simulation Results:\n";
    std::cout << "Total Requests: " << totalRequests << "\n";
    std::cout << "Satisfied Requests: " << satisfiedRequests << "\n";
    std::cout << "Unsatisfied Requests: " << unsatisfiedRequests << "\n";
    std::cout << "Smallest Block Requested: " << smallestBlock << "\n";
    std::cout << "Largest Block Requested: " << largestBlock << "\n";
    std::cout << "Average Block Size: " << averageBlockSize << "\n";
    std::cout << "Shortest Lease: " << shortestLease << "\n";
    std::cout << "Longest Lease: " << longestLease << "\n";
    std::cout << "Average Lease Time: " << averageLeaseTime << "\n";
    std::cout << "Number of Merges: " << mergeCount << "\n";
    std::cout << "Free List:\n";
    for (const auto &r : freeList) {
        std::cout << "Start: " << r.first << ", Size: " << r.second << "\n";
    }
    std::cout << "Allocated List:\n";
    for (const auto &a : allocatedList) {
        std::cout << "Start: " << a.first.first << ", Size: " << a.first.second 
                  << ", Lease Expiry: " << a.second << "\n";
    }
}