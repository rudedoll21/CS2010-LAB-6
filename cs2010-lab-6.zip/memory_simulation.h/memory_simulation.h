#ifndef MEMORY_SIMULATION_H
#define MEMORY_SIMULATION_H

#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>

using range = std::pair<int, int>;
using alloc = std::pair<range, int>;

// Constants
const int MIN_LEASE = 40;
const int MAX_LEASE = 70;
const int MIN_SIZE = 50;
const int MAX_SIZE = 350;
const int TIME_LIMIT = 1000;
const int REQUEST_INTERVAL = 10;
const int MEMORY_SIZE = 1000;

// Function Declarations
void generateMemoryRequest(int clock, std::vector<range> &freeList, std::vector<alloc> &allocatedList, 
                           int &totalRequests, int &satisfiedRequests, int &unsatisfiedRequests, 
                           int &smallestBlock, int &largestBlock, int &totalBlockSize, 
                           int &shortestLease, int &longestLease, int &totalLeaseTime, int &mergeCount);
void checkLeaseExpiry(int clock, std::vector<range> &freeList, std::vector<alloc> &allocatedList);
void mergeFreeList(std::vector<range> &freeList);
void printStatistics(int totalRequests, int satisfiedRequests, int unsatisfiedRequests, 
                     int smallestBlock, int largestBlock, double averageBlockSize, 
                     int shortestLease, int longestLease, double averageLeaseTime, 
                     int mergeCount, const std::vector<range> &freeList, const std::vector<alloc> &allocatedList);

#endif