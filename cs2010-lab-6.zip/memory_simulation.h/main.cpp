#include "memory_simulation.h"

int main() {
    long int clock = 0;
    int totalRequests = 0, satisfiedRequests = 0, unsatisfiedRequests = 0;
    int smallestBlock = MAX_SIZE, largestBlock = MIN_SIZE, totalBlockSize = 0;
    int shortestLease = MAX_LEASE, longestLease = MIN_LEASE, totalLeaseTime = 0;
    int mergeCount = 0;

    std::vector<range> freeList = {{0, MEMORY_SIZE}};
    std::vector<alloc> allocatedList;

    while (++clock <= TIME_LIMIT) {
        if (clock % REQUEST_INTERVAL == 0) {
            generateMemoryRequest(clock, freeList, allocatedList, totalRequests, satisfiedRequests, unsatisfiedRequests, 
                                  smallestBlock, largestBlock, totalBlockSize, shortestLease, longestLease, totalLeaseTime, mergeCount);
        }

        checkLeaseExpiry(clock, freeList, allocatedList);
    }

    double averageBlockSize = static_cast<double>(totalBlockSize) / totalRequests;
    double averageLeaseTime = static_cast<double>(totalLeaseTime) / totalRequests;

    printStatistics(totalRequests, satisfiedRequests, unsatisfiedRequests, 
                    smallestBlock, largestBlock, averageBlockSize, 
                    shortestLease, longestLease, averageLeaseTime, 
                    mergeCount, freeList, allocatedList);

    return 0;
}